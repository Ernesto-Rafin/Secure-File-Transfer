﻿using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;

class SecureFileClient
{
    private const int Port = 5000;
    private const string ServerIp = "127.0.0.1";
    private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890123456");
    private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdefghijklmnop");

    static void Main()
    {
        Console.WriteLine("Secure File Transfer Client");
        Console.WriteLine("Commands:");
        Console.WriteLine("upload <filepath>");
        Console.WriteLine("download <filename>");
        Console.WriteLine("list");
        Console.WriteLine("exit\n");

        while (true)
        {
            Console.Write("> ");
            string? input = Console.ReadLine();

            if (input == null) continue;

            if (input.StartsWith("upload"))
                Upload(input.Split(" ")[1]);

            else if (input.StartsWith("download"))
                Download(input.Split(" ")[1]);

            else if (input == "list")
                ListFiles();

            else if (input == "exit")
                break;

            else
                Console.WriteLine("Invalid command.");
        }
    }

    static void Upload(string filepath)
    {
        if (!File.Exists(filepath))
        {
            Console.WriteLine("File not found.");
            return;
        }

        TcpClient client = new(ServerIp, Port);
        NetworkStream stream = client.GetStream();
        StreamWriter writer = new(stream) { AutoFlush = true };

        string filename = Path.GetFileName(filepath);
        byte[] data = File.ReadAllBytes(filepath);

        using Aes aes = Aes.Create();
        aes.Key = Key;
        aes.IV = IV;

        byte[] encrypted;

        using (MemoryStream ms = new())
        using (CryptoStream crypto = new(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
        {
            crypto.Write(data, 0, data.Length);
            crypto.Close();
            encrypted = ms.ToArray();
        }

        writer.WriteLine($"UPLOAD {filename}");
        writer.WriteLine(encrypted.Length);
        stream.Write(encrypted, 0, encrypted.Length);

        client.Close();
        Console.WriteLine("Uploaded.");
    }

    static void Download(string filename)
    {
        TcpClient client = new(ServerIp, Port);
        NetworkStream stream = client.GetStream();
        StreamReader reader = new(stream);
        StreamWriter writer = new(stream) { AutoFlush = true };

        writer.WriteLine($"DOWNLOAD {filename}");

        string response = reader.ReadLine();
        if (response == "ERROR")
        {
            Console.WriteLine("File not found on server.");
            return;
        }

        long size = long.Parse(reader.ReadLine());
        byte[] encrypted = new byte[size];
        stream.Read(encrypted, 0, encrypted.Length);

        using Aes aes = Aes.Create();
        aes.Key = Key;
        aes.IV = IV;

        byte[] decrypted;

        using (MemoryStream ms = new(encrypted))
        using (CryptoStream crypto = new(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
        using (MemoryStream output = new())
        {
            crypto.CopyTo(output);
            decrypted = output.ToArray();
        }

        File.WriteAllBytes(filename, decrypted);
        Console.WriteLine("Downloaded.");
    }

    static void ListFiles()
    {
        TcpClient client = new(ServerIp, Port);
        NetworkStream stream = client.GetStream();
        StreamReader reader = new(stream);
        StreamWriter writer = new(stream) { AutoFlush = true };

        writer.WriteLine("LIST");

        string line;
        Console.WriteLine("\nFiles on server:");

        while ((line = reader.ReadLine()) != "END")
            Console.WriteLine(" - " + line);

        Console.WriteLine("");
        client.Close();
    }
}
