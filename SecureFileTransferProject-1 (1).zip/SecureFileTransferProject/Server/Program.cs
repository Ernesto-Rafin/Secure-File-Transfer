﻿using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;

class SecureFileServer
{
    private const int Port = 5000;
    private static readonly string StoragePath = Path.Combine(Directory.GetCurrentDirectory(), "files");
    private static readonly byte[] Key = Encoding.UTF8.GetBytes("1234567890123456");
    private static readonly byte[] IV = Encoding.UTF8.GetBytes("abcdefghijklmnop");

    static void Main()
    {
        if (!Directory.Exists(StoragePath))
            Directory.CreateDirectory(StoragePath);

        Console.WriteLine("Secure File Transfer Server");
        Console.WriteLine($"Server running on port {Port}...\n");

        TcpListener listener = new TcpListener(IPAddress.Any, Port);
        listener.Start();

        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            Console.WriteLine("Client connected.");
            HandleClient(client);
        }
    }

    private static void HandleClient(TcpClient client)
    {
        NetworkStream stream = client.GetStream();
        StreamReader reader = new(stream);
        StreamWriter writer = new(stream) { AutoFlush = true };

        string command = reader.ReadLine();

        // ---------------------- UPLOAD ----------------------
        if (command.StartsWith("UPLOAD"))
        {
            string filename = command.Split(" ")[1];
            long fileSize = long.Parse(reader.ReadLine());

            string path = Path.Combine(StoragePath, filename);

            using FileStream fs = new(path, FileMode.Create);
            using Aes aes = Aes.Create();
            aes.Key = Key;
            aes.IV = IV;

            using CryptoStream crypto = new(fs, aes.CreateDecryptor(), CryptoStreamMode.Write);
            stream.CopyTo(crypto);

            Console.WriteLine($"Uploaded: {filename}");
        }

        // ---------------------- DOWNLOAD ----------------------
        else if (command.StartsWith("DOWNLOAD"))
        {
            string filename = command.Split(" ")[1];
            string path = Path.Combine(StoragePath, filename);

            if (!File.Exists(path))
            {
                writer.WriteLine("ERROR");
                return;
            }

            writer.WriteLine("OK");

            byte[] data = File.ReadAllBytes(path);

            using Aes aes = Aes.Create();
            aes.Key = Key;
            aes.IV = IV;

            byte[] encrypted;

            using (MemoryStream ms = new())
            using (CryptoStream crypto = new(ms, aes.CreateEncryptor(), CryptoStreamMode.Write))
            {
                crypto.Write(data, 0, data.Length);
                crypto.Close();
                encrypted = ms.ToArray();
            }

            writer.WriteLine(encrypted.Length);
            stream.Write(encrypted, 0, encrypted.Length);

            Console.WriteLine($"Downloaded: {filename}");
        }

        // ---------------------- LIST ----------------------
        else if (command == "LIST")
        {
            string[] files = Directory.GetFiles(StoragePath);

            foreach (var f in files)
                writer.WriteLine(Path.GetFileName(f));

            writer.WriteLine("END");
        }

        client.Close();
    }
}
